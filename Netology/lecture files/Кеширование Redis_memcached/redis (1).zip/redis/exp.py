import requests

def load_pic(pic_url: str, filename: str) -> None:
    
    # pic_dump = client.get(pic_url)
    
    if not pic_dump:
        # print('not cache')
        r = requests.get(pic_url)
        if r.status_code == 200:
            pic_dump = r.content
            # client.set(pic_url, pic_dump)
        
    with open(filename, 'wb') as f:
        f.write(pic_dump)
        
        
PIC_URL = 'https://cimg1.ibsrv.net/ibimg/hgm/1920x1080-1/100/894/acura-zdx_100894585.jpg'
    
load_pic(PIC_URL, PIC_URL.split('/')[-1])